import { ShoppingBag, Wallet, Users2, TrendingUp } from "lucide-react";
import { StatCard } from "@/components/admin/stat-card";
import { formatPLN } from "@/lib/utils";
import { createClient } from "@/lib/supabase/server";

// In production these four queries replace the MOCK_* fallbacks below —
// left inline as fallbacks so the dashboard renders before the schema is seeded.
async function getTodayStats() {
  const supabase = await createClient();
  const since = new Date();
  since.setHours(0, 0, 0, 0);

  const { count: orderCount } = await supabase
    .from("orders")
    .select("id", { count: "exact", head: true })
    .gte("created_at", since.toISOString());

  const { data: revenueRows } = await supabase
    .from("orders")
    .select("total")
    .gte("created_at", since.toISOString());

  const revenue = revenueRows?.reduce((sum, row) => sum + (row.total ?? 0), 0) ?? null;

  return {
    orders: orderCount ?? null,
    revenue
  };
}

const MOCK_RECENT_ORDERS = [
  { id: "#3021", customer: "Anna Nowak", branch: "Śródmieście", total: 84, status: "Preparing" },
  { id: "#3020", customer: "Piotr Zieliński", branch: "Rynek", total: 46, status: "Out for delivery" },
  { id: "#3019", customer: "Farhana R.", branch: "Śródmieście", total: 132, status: "Delivered" }
];

export default async function AdminDashboardPage() {
  const stats = await getTodayStats();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl">Today at a glance</h1>
        <p className="text-sm text-bone/50">Across all branches, refreshed in real time.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Today's orders"
          value={stats.orders !== null ? String(stats.orders) : "—"}
          delta={{ value: "12%", positive: true }}
          icon={ShoppingBag}
        />
        <StatCard
          label="Revenue"
          value={stats.revenue !== null ? formatPLN(stats.revenue) : "—"}
          delta={{ value: "4%", positive: true }}
          icon={Wallet}
        />
        <StatCard label="New customers" value="18" delta={{ value: "2%", positive: false }} icon={Users2} />
        <StatCard label="Avg. order value" value={formatPLN(46.5)} icon={TrendingUp} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 lg:col-span-2">
          <h2 className="font-display text-lg">Recent orders</h2>
          <table className="mt-4 w-full text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wide text-bone/40">
                <th className="pb-2 font-medium">Order</th>
                <th className="pb-2 font-medium">Customer</th>
                <th className="pb-2 font-medium">Branch</th>
                <th className="pb-2 font-medium">Total</th>
                <th className="pb-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {MOCK_RECENT_ORDERS.map((order) => (
                <tr key={order.id}>
                  <td className="py-2.5 font-mono text-xs">{order.id}</td>
                  <td className="py-2.5">{order.customer}</td>
                  <td className="py-2.5 text-bone/60">{order.branch}</td>
                  <td className="py-2.5 font-mono">{formatPLN(order.total)}</td>
                  <td className="py-2.5 text-bone/60">{order.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="font-display text-lg">Top branches today</h2>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex justify-between"><span>Warszawa Śródmieście</span><span className="font-mono text-bone/60">{formatPLN(2840)}</span></li>
            <li className="flex justify-between"><span>Kraków Stare Miasto</span><span className="font-mono text-bone/60">{formatPLN(1975)}</span></li>
            <li className="flex justify-between"><span>Wrocław Rynek</span><span className="font-mono text-bone/60">{formatPLN(1410)}</span></li>
          </ul>
        </div>
      </div>
    </div>
  );
}
