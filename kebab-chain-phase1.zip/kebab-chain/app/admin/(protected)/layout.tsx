import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AdminSidebar } from "@/components/admin/sidebar";

export default async function ProtectedAdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) redirect("/admin/login");

  // `staff` table holds the role-based permission grid (admin, manager, branch_manager,
  // cashier, kitchen_staff, delivery_staff) — see the Supabase schema. RLS also enforces
  // this at the query level; this check just controls whether the dashboard renders at all.
  const { data: staffRecord } = await supabase
    .from("staff")
    .select("role, is_active")
    .eq("user_id", user.id)
    .single();

  if (!staffRecord || !staffRecord.is_active) redirect("/admin/login");

  return (
    <div className="flex min-h-screen bg-charcoal text-bone">
      <AdminSidebar role={staffRecord.role} />
      <div className="flex-1 overflow-x-hidden">
        <header className="flex h-16 items-center justify-between border-b border-white/10 px-6">
          <span className="font-mono text-xs uppercase tracking-widest text-bone/50">
            {staffRecord.role.replace("_", " ")}
          </span>
          <span className="text-sm text-bone/70">{user.email}</span>
        </header>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}
