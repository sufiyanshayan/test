import type { Metadata } from "next";
import { Fraunces, Public_Sans, IBM_Plex_Mono } from "next/font/google";
import { ThemeProvider } from "@/components/theme-provider";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin", "latin-ext"],
  variable: "--font-fraunces",
  weight: ["400", "500", "600"],
  style: ["normal", "italic"]
});

const publicSans = Public_Sans({
  subsets: ["latin", "latin-ext"],
  variable: "--font-public-sans",
  weight: ["400", "500", "600", "700"]
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  variable: "--font-plex-mono",
  weight: ["400", "500"]
});

export const metadata: Metadata = {
  title: {
    default: "SHIKHA — Flame-cut kebab, Dhaka to Warsaw",
    template: "%s · SHIKHA"
  },
  description:
    "SHIKHA is a premium kebab house chain in Poland, cutting meat fresh to order with recipes drawn from Bangladeshi spice traditions."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pl" suppressHydrationWarning>
      <body
        className={`${fraunces.variable} ${publicSans.variable} ${plexMono.variable} font-body bg-bone text-charcoal antialiased dark:bg-charcoal dark:text-bone`}
      >
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
