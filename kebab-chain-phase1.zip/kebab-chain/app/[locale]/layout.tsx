import { notFound } from "next/navigation";
import { locales, isLocale } from "@/lib/i18n/config";
import { IntlProvider } from "@/lib/i18n/provider";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

async function getMessages(locale: string) {
  return (await import(`@/messages/${locale}.json`)).default;
}

export default async function LocaleLayout({
  children,
  params
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();

  const messages = await getMessages(locale);

  return (
    <IntlProvider locale={locale} messages={messages}>
      <SiteHeader />
      <main>{children}</main>
      <SiteFooter />
    </IntlProvider>
  );
}
