import type { Metadata } from "next";
import { Hero } from "@/components/home/hero";
import { FeaturedFoods } from "@/components/home/featured-foods";
import { BranchesPreview } from "@/components/home/branches-preview";
import { WhyChooseUs } from "@/components/home/why-choose-us";
import { Testimonials } from "@/components/home/testimonials";
import { FAQ } from "@/components/home/faq";

export const metadata: Metadata = {
  title: "SHIKHA — Flame-cut kebab, Dhaka to Warsaw",
  alternates: {
    languages: { en: "/en", pl: "/pl", bn: "/bn" }
  }
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedFoods />
      <BranchesPreview />
      <WhyChooseUs />
      <Testimonials />
      <FAQ />
    </>
  );
}
