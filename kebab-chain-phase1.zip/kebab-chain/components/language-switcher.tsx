"use client";

import { useState, useTransition } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Globe } from "lucide-react";
import { locales, localeNames, type Locale } from "@/lib/i18n/config";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({ current }: { current: Locale }) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const pathname = usePathname();
  const router = useRouter();

  function switchTo(locale: Locale) {
    const rest = pathname.split("/").slice(2).join("/");
    const nextPath = `/${locale}${rest ? `/${rest}` : ""}`;
    document.cookie = `kebab_locale=${locale};path=/;max-age=31536000`;
    startTransition(() => router.push(nextPath));
    setOpen(false);
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label="Change language"
        disabled={isPending}
        className="flex h-9 items-center gap-1.5 rounded-full border border-charcoal-line/40 px-3 text-xs font-medium text-charcoal/80 transition-colors hover:border-saffron/60 dark:border-white/10 dark:text-bone/80"
      >
        <Globe size={14} />
        {localeNames[current]}
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-50 w-36 overflow-hidden rounded-2xl border border-charcoal-line/30 bg-bone shadow-xl dark:border-white/10 dark:bg-charcoal-soft">
          {locales.map((locale) => (
            <button
              key={locale}
              onClick={() => switchTo(locale)}
              className={cn(
                "block w-full px-4 py-2.5 text-left text-sm transition-colors hover:bg-saffron/10",
                locale === current && "text-saffron font-semibold"
              )}
            >
              {localeNames[locale]}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
