"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  UtensilsCrossed,
  Tag,
  ShoppingBag,
  Users,
  Building2,
  Image as ImageIcon,
  MessageSquare,
  Settings,
  LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

const NAV = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["all"] },
  { href: "/admin/menu", label: "Menu & Categories", icon: UtensilsCrossed, roles: ["admin", "manager", "branch_manager"] },
  { href: "/admin/offers", label: "Offers & Coupons", icon: Tag, roles: ["admin", "manager"] },
  { href: "/admin/orders", label: "Orders", icon: ShoppingBag, roles: ["all"] },
  { href: "/admin/customers", label: "Customers", icon: Users, roles: ["admin", "manager"] },
  { href: "/admin/branches", label: "Branches", icon: Building2, roles: ["admin", "manager"] },
  { href: "/admin/gallery", label: "Gallery & Media", icon: ImageIcon, roles: ["admin", "manager"] },
  { href: "/admin/messages", label: "Reviews & Messages", icon: MessageSquare, roles: ["admin", "manager", "branch_manager"] },
  { href: "/admin/settings", label: "Settings", icon: Settings, roles: ["admin"] }
];

export function AdminSidebar({ role }: { role: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const visible = NAV.filter((item) => item.roles.includes("all") || item.roles.includes(role));

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/admin/login");
  }

  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-white/10 bg-white/[0.02] md:flex">
      <div className="flex h-16 items-center gap-2 border-b border-white/10 px-6 font-display text-lg">
        SHIKHA <span className="text-xs font-mono text-bone/40">admin</span>
      </div>
      <nav className="flex-1 space-y-1 p-3">
        {visible.map((item) => {
          const active = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href as any}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
                active ? "bg-saffron/15 text-saffron" : "text-bone/60 hover:bg-white/5 hover:text-bone"
              )}
            >
              <item.icon size={16} />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <button
        onClick={handleLogout}
        className="m-3 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-bone/50 hover:bg-white/5 hover:text-ember"
      >
        <LogOut size={16} /> Sign out
      </button>
    </aside>
  );
}
