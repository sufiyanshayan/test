import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export function StatCard({
  label,
  value,
  delta,
  icon: Icon
}: {
  label: string;
  value: string;
  delta?: { value: string; positive: boolean };
  icon: LucideIcon;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-bone/50">{label}</span>
        <Icon size={16} className="text-saffron" />
      </div>
      <p className="mt-3 font-display text-2xl">{value}</p>
      {delta && (
        <p className={cn("mt-1 text-xs font-medium", delta.positive ? "text-teal" : "text-ember")}>
          {delta.positive ? "▲" : "▼"} {delta.value} vs. yesterday
        </p>
      )}
    </div>
  );
}
