"use client";

import Link from "next/link";
import { Facebook, Instagram, Music2 } from "lucide-react";
import { useLocale, useTranslations } from "@/lib/i18n/provider";

export function SiteFooter() {
  const locale = useLocale();
  const t = useTranslations("footer");
  const nav = useTranslations("nav");
  const brand = useTranslations("brand");

  return (
    <footer className="border-t border-charcoal-line/15 bg-charcoal text-bone dark:border-white/10">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-4">
          <div>
            <p className="font-display text-2xl">{brand("name")}</p>
            <p className="mt-2 max-w-xs text-sm text-bone/60">{brand("tagline")}</p>
            <div className="mt-5 flex gap-3">
              {[Facebook, Instagram, Music2].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 transition-colors hover:border-saffron hover:text-saffron"
                >
                  <Icon size={15} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <p className="eyebrow mb-4">{t("explore")}</p>
            <ul className="space-y-2.5 text-sm text-bone/70">
              <li><Link href={`/${locale}/menu` as any}>{nav("menu")}</Link></li>
              <li><Link href={`/${locale}/branches` as any}>{nav("branches")}</Link></li>
              <li><Link href={`/${locale}/about` as any}>{nav("about")}</Link></li>
              <li><Link href={`/${locale}/contact` as any}>{nav("contact")}</Link></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-4">{t("legal")}</p>
            <ul className="space-y-2.5 text-sm text-bone/70">
              <li><Link href={`/${locale}/privacy` as any}>Privacy Policy</Link></li>
              <li><Link href={`/${locale}/terms` as any}>Terms of Service</Link></li>
              <li><Link href={`/${locale}/cookies` as any}>Cookie Policy</Link></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-4">{t("newsletter_title")}</p>
            <p className="mb-3 text-sm text-bone/60">{t("newsletter_body")}</p>
            <form className="flex gap-2">
              <input
                type="email"
                required
                placeholder="you@email.com"
                className="w-full rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm outline-none placeholder:text-bone/40 focus-visible:border-saffron"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-saffron px-4 py-2 text-xs font-semibold text-charcoal"
              >
                {t("newsletter_cta")}
              </button>
            </form>
          </div>
        </div>

        <div className="mt-14 border-t border-white/10 pt-6 text-xs text-bone/40">
          © {new Date().getFullYear()} {brand("name")}. {t("rights")}
        </div>
      </div>
    </footer>
  );
}
