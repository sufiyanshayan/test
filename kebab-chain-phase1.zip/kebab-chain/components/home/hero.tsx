"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Phone, MapPin, CalendarCheck } from "lucide-react";
import { useLocale, useTranslations } from "@/lib/i18n/provider";

export function Hero() {
  const locale = useLocale();
  const t = useTranslations("hero");

  return (
    <section className="relative overflow-hidden bg-charcoal text-bone">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 md:grid-cols-2 md:py-28 lg:px-8">
        <div className="flex flex-col justify-center">
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="eyebrow"
          >
            {t("eyebrow")}
          </motion.p>

          <h1 className="mt-4 font-display text-5xl leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            <motion.span
              initial={{ clipPath: "inset(0 100% 0 0)" }}
              animate={{ clipPath: "inset(0 0% 0 0)" }}
              transition={{ duration: 0.9, ease: [0.77, 0, 0.18, 1] }}
              className="block"
            >
              {t("headline_1")}
            </motion.span>
            <motion.span
              initial={{ clipPath: "inset(0 100% 0 0)" }}
              animate={{ clipPath: "inset(0 0% 0 0)" }}
              transition={{ duration: 0.9, delay: 0.15, ease: [0.77, 0, 0.18, 1] }}
              className="block italic text-saffron"
            >
              {t("headline_2")}
            </motion.span>
          </h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-6 max-w-md text-balance text-bone/70"
          >
            {t("body")}
          </motion.p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Link
              href={`/${locale}/order` as any}
              className="rounded-full bg-ember px-6 py-3 text-sm font-semibold transition-transform hover:scale-[1.03]"
            >
              {t("cta_primary")}
            </Link>
            <Link
              href={`/${locale}/reserve` as any}
              className="flex items-center gap-2 rounded-full border border-white/20 px-6 py-3 text-sm font-semibold transition-colors hover:border-saffron"
            >
              <CalendarCheck size={15} /> {t("cta_secondary")}
            </Link>
            <a href="tel:+48000000000" className="flex items-center gap-2 px-3 py-3 text-sm font-medium text-bone/70 hover:text-saffron">
              <Phone size={15} /> {t("cta_call")}
            </a>
            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-3 py-3 text-sm font-medium text-bone/70 hover:text-saffron"
            >
              <MapPin size={15} /> {t("cta_maps")}
            </a>
          </div>
        </div>

        {/* Signature element: a slow-turning spit silhouette, the one visual every branch shares */}
        <div className="relative flex items-center justify-center [perspective:1200px]">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative h-72 w-72 sm:h-96 sm:w-96"
          >
            <div className="absolute left-1/2 top-0 h-full w-1 -translate-x-1/2 bg-gradient-to-b from-saffron via-ember to-transparent" />
            <div className="absolute inset-0 animate-spit-turn rounded-[40%] bg-gradient-to-br from-ember/80 via-saffron/70 to-teal/60 opacity-90 blur-[2px] [transform-style:preserve-3d]" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="rounded-full bg-charcoal/70 px-4 py-1.5 font-mono text-[11px] uppercase tracking-widest text-saffron backdrop-blur">
                slow-turned, hand-shaved
              </span>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="h-10 w-full bg-bone dark:bg-charcoal-soft cut-divider" />
    </section>
  );
}
