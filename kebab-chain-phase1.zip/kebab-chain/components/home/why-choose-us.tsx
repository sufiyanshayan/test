"use client";

import { UtensilsCrossed, Soup, UserCheck } from "lucide-react";
import { useTranslations } from "@/lib/i18n/provider";

export function WhyChooseUs() {
  const t = useTranslations("why");

  const items = [
    { icon: UtensilsCrossed, title: t("item_1_title"), body: t("item_1_body") },
    { icon: Soup, title: t("item_2_title"), body: t("item_2_body") },
    { icon: UserCheck, title: t("item_3_title"), body: t("item_3_body") }
  ];

  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <p className="eyebrow">{t("eyebrow")}</p>
      <h2 className="mt-3 max-w-xl font-display text-3xl sm:text-4xl">{t("title")}</h2>

      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {items.map(({ icon: Icon, title, body }) => (
          <div key={title} className="rounded-3xl border border-charcoal-line/15 p-7 dark:border-white/10">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-saffron/15 text-ember dark:text-saffron">
              <Icon size={20} />
            </div>
            <h3 className="mt-5 font-display text-xl">{title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-charcoal/60 dark:text-bone/60">{body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
