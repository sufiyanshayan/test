"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { useTranslations } from "@/lib/i18n/provider";
import { cn } from "@/lib/utils";

const ITEMS = [
  { q: "Do you deliver outside city centre?", a: "Each branch has its own delivery zone, shown at checkout once you enter your address." },
  { q: "Is there a halal guarantee?", a: "Yes — all meat across every branch is halal-certified, listed on each branch's page." },
  { q: "Can I reserve a table for a group?", a: "Yes, use the Reserve a Table button and select party size; larger groups can also call the branch directly." }
];

export function FAQ() {
  const t = useTranslations("faq");
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="mx-auto max-w-3xl px-4 py-20 sm:px-6 lg:px-8">
      <p className="eyebrow">{t("eyebrow")}</p>
      <h2 className="mt-3 font-display text-3xl sm:text-4xl">{t("title")}</h2>

      <div className="mt-8 divide-y divide-charcoal-line/15 dark:divide-white/10">
        {ITEMS.map((item, i) => (
          <div key={item.q}>
            <button
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
              className="flex w-full items-center justify-between py-5 text-left"
              aria-expanded={openIndex === i}
            >
              <span className="font-display text-lg">{item.q}</span>
              <ChevronDown
                size={18}
                className={cn("shrink-0 transition-transform", openIndex === i && "rotate-180 text-ember")}
              />
            </button>
            {openIndex === i && (
              <p className="pb-5 text-sm leading-relaxed text-charcoal/60 dark:text-bone/60">{item.a}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
