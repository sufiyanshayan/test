"use client";

import Link from "next/link";
import { MapPin, Clock } from "lucide-react";
import { useLocale, useTranslations } from "@/lib/i18n/provider";
import { cn } from "@/lib/utils";

// Mirrors the future `branches` table: name, address, phone, opening_hours, status.
const BRANCHES = [
  { id: "1", name: "Warszawa Śródmieście", address: "ul. Marszałkowska 12", open: true, hours: "10:00 – 23:00" },
  { id: "2", name: "Kraków Stare Miasto", address: "ul. Floriańska 5", open: true, hours: "11:00 – 22:00" },
  { id: "3", name: "Wrocław Rynek", address: "Rynek 34", open: false, hours: "11:00 – 22:00" }
] as const;

export function BranchesPreview() {
  const locale = useLocale();
  const t = useTranslations("branches");

  return (
    <section className="bg-bone-soft py-20 dark:bg-charcoal-soft">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">{t("eyebrow")}</p>
            <h2 className="mt-3 font-display text-3xl sm:text-4xl">{t("title")}</h2>
            <p className="mt-2 max-w-lg text-charcoal/60 dark:text-bone/60">{t("subtitle")}</p>
          </div>
          <Link
            href={`/${locale}/branches` as any}
            className="rounded-full border border-charcoal-line/30 px-5 py-2.5 text-sm font-semibold hover:border-ember hover:text-ember dark:border-white/15"
          >
            {t("view_all")}
          </Link>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {BRANCHES.map((branch) => (
            <div
              key={branch.id}
              className="rounded-3xl border border-charcoal-line/15 bg-bone p-6 dark:border-white/10 dark:bg-white/[0.03]"
            >
              <div className="flex items-start justify-between">
                <h3 className="font-display text-xl">{branch.name}</h3>
                <span
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold",
                    branch.open ? "bg-teal/15 text-teal dark:text-teal" : "bg-ember/10 text-ember"
                  )}
                >
                  <span className={cn("h-1.5 w-1.5 rounded-full", branch.open ? "bg-teal" : "bg-ember")} />
                  {branch.open ? t("open") : t("closed")}
                </span>
              </div>
              <p className="mt-3 flex items-center gap-2 text-sm text-charcoal/60 dark:text-bone/60">
                <MapPin size={14} /> {branch.address}
              </p>
              <p className="mt-1.5 flex items-center gap-2 text-sm text-charcoal/60 dark:text-bone/60">
                <Clock size={14} /> {branch.hours}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
