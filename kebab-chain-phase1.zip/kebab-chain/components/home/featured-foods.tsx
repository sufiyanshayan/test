"use client";

import { Flame, Leaf, Sparkles } from "lucide-react";
import { useTranslations } from "@/lib/i18n/provider";
import { formatPLN, cn } from "@/lib/utils";

// Shape mirrors the future `foods` table (see Supabase schema): id, name, price,
// discount_price, calories, spicy_level (0-3), is_popular, is_new, is_vegetarian.
const FEATURED = [
  { id: "1", name: "Beef Döner Special", price: 24, discountPrice: null, calories: 640, spicy: 1, badge: "popular" },
  { id: "2", name: "Lamb Adana Wrap", price: 27, discountPrice: 22, calories: 590, spicy: 2, badge: "new" },
  { id: "3", name: "Chicken Charcoal Box", price: 21, discountPrice: null, calories: 510, spicy: 1, badge: null },
  { id: "4", name: "Paneer Ember Wrap", price: 19, discountPrice: null, calories: 430, spicy: 2, badge: "vegetarian" }
] as const;

export function FeaturedFoods() {
  const t = useTranslations("featured");

  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <p className="eyebrow">{t("eyebrow")}</p>
      <h2 className="mt-3 font-display text-3xl sm:text-4xl">{t("title")}</h2>
      <p className="mt-2 max-w-lg text-charcoal/60 dark:text-bone/60">{t("subtitle")}</p>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURED.map((item) => (
          <article
            key={item.id}
            className="group overflow-hidden rounded-3xl border border-charcoal-line/15 bg-bone-soft/60 transition-shadow hover:shadow-xl dark:border-white/10 dark:bg-white/[0.03]"
          >
            <div className="relative aspect-[4/3] bg-gradient-to-br from-ember/30 via-saffron/20 to-teal/20">
              {item.badge && (
                <span
                  className={cn(
                    "absolute left-3 top-3 flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide",
                    item.badge === "popular" && "bg-ember text-bone",
                    item.badge === "new" && "bg-saffron text-charcoal",
                    item.badge === "vegetarian" && "bg-teal text-bone"
                  )}
                >
                  {item.badge === "vegetarian" && <Leaf size={10} />}
                  {item.badge === "new" && <Sparkles size={10} />}
                  {item.badge}
                </span>
              )}
            </div>

            <div className="p-5">
              <h3 className="font-display text-lg">{item.name}</h3>
              <div className="mt-1.5 flex items-center gap-3 font-mono text-xs text-charcoal/50 dark:text-bone/50">
                <span>{item.calories} kcal</span>
                <span className="flex items-center gap-0.5">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Flame
                      key={i}
                      size={11}
                      className={i < item.spicy ? "fill-ember text-ember" : "text-charcoal-line/40 dark:text-white/15"}
                    />
                  ))}
                </span>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="font-mono text-base">
                  {item.discountPrice ? (
                    <>
                      <span className="mr-2 text-charcoal/40 line-through dark:text-bone/30">
                        {formatPLN(item.price)}
                      </span>
                      <span className="text-ember">{formatPLN(item.discountPrice)}</span>
                    </>
                  ) : (
                    formatPLN(item.price)
                  )}
                </div>
                <button className="rounded-full border border-charcoal-line/30 px-3 py-1.5 text-xs font-semibold transition-colors group-hover:border-ember group-hover:text-ember dark:border-white/15">
                  Add
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
