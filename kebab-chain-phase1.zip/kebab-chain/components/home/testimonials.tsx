"use client";

import { Star } from "lucide-react";
import { useTranslations } from "@/lib/i18n/provider";

const REVIEWS = [
  { name: "Kasia W.", rating: 5, quote: "Najlepszy kebab jaki jadłam w Warszawie, mięso zawsze świeże." },
  { name: "Tomasz K.", rating: 5, quote: "Przypomina mi kebab z podróży do Stambułu — bez przesady." },
  { name: "Rafiul A.", rating: 5, quote: "Feels like home. The spice blend is exactly right." }
];

export function Testimonials() {
  const t = useTranslations("testimonials");

  return (
    <section className="bg-charcoal py-20 text-bone">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="eyebrow">{t("eyebrow")}</p>
        <h2 className="mt-3 font-display text-3xl sm:text-4xl">{t("title")}</h2>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {REVIEWS.map((review) => (
            <div key={review.name} className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
              <div className="flex gap-0.5 text-saffron">
                {Array.from({ length: review.rating }).map((_, i) => (
                  <Star key={i} size={14} className="fill-saffron" />
                ))}
              </div>
              <p className="mt-4 text-sm leading-relaxed text-bone/80">"{review.quote}"</p>
              <p className="mt-4 font-mono text-xs uppercase tracking-wide text-bone/40">{review.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
