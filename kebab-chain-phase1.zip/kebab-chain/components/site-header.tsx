"use client";

import Link from "next/link";
import { Phone } from "lucide-react";
import { useLocale, useTranslations } from "@/lib/i18n/provider";
import { LanguageSwitcher } from "@/components/language-switcher";
import { ThemeToggle } from "@/components/theme-toggle";

export function SiteHeader() {
  const locale = useLocale();
  const t = useTranslations("nav");
  const tTheme = useTranslations("theme");
  const brand = useTranslations("brand");

  const links = [
    { href: `/${locale}/menu`, label: t("menu") },
    { href: `/${locale}/branches`, label: t("branches") },
    { href: `/${locale}/about`, label: t("about") },
    { href: `/${locale}/contact`, label: t("contact") }
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-charcoal-line/15 bg-bone/80 backdrop-blur-lg dark:border-white/10 dark:bg-charcoal/70">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href={`/${locale}`} className="font-display text-xl font-semibold tracking-tight">
          {brand("name")}
        </Link>

        <nav className="hidden items-center gap-7 md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href as any}
              className="text-sm font-medium text-charcoal/70 transition-colors hover:text-ember dark:text-bone/70 dark:hover:text-saffron"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href="tel:+48000000000"
            className="hidden h-9 items-center gap-1.5 rounded-full border border-charcoal-line/40 px-3 text-xs font-medium sm:flex dark:border-white/10"
          >
            <Phone size={13} /> {t("call")}
          </a>
          <LanguageSwitcher current={locale} />
          <ThemeToggle labels={{ light: tTheme("light"), dark: tTheme("dark"), system: tTheme("system") }} />
          <Link
            href={`/${locale}/order` as any}
            className="ml-1 hidden h-9 items-center rounded-full bg-ember px-4 text-sm font-semibold text-bone transition-transform hover:scale-[1.03] sm:flex"
          >
            {t("order")}
          </Link>
        </div>
      </div>
    </header>
  );
}
