export const locales = ["en", "pl", "bn"] as const;
export type Locale = (typeof locales)[number];

export const defaultLocale: Locale = "pl";

export const localeNames: Record<Locale, string> = {
  en: "English",
  pl: "Polski",
  bn: "বাংলা"
};

export function isLocale(value: string): value is Locale {
  return (locales as readonly string[]).includes(value);
}
