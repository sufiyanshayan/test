"use client";

import { createContext, useContext, type ReactNode } from "react";
import type { Locale } from "@/lib/i18n/config";

type Messages = Record<string, any>;

const IntlContext = createContext<{ locale: Locale; messages: Messages } | null>(null);

export function IntlProvider({
  locale,
  messages,
  children
}: {
  locale: Locale;
  messages: Messages;
  children: ReactNode;
}) {
  return <IntlContext.Provider value={{ locale, messages }}>{children}</IntlContext.Provider>;
}

/** Dot-path translation lookup, e.g. t("hero.headline_1") */
export function useTranslations(namespace?: string) {
  const ctx = useContext(IntlContext);
  if (!ctx) throw new Error("useTranslations must be used within an IntlProvider");

  return (key: string) => {
    const fullKey = namespace ? `${namespace}.${key}` : key;
    const value = fullKey
      .split(".")
      .reduce<any>((acc, part) => (acc && typeof acc === "object" ? acc[part] : undefined), ctx.messages);
    return typeof value === "string" ? value : fullKey;
  };
}

export function useLocale() {
  const ctx = useContext(IntlContext);
  if (!ctx) throw new Error("useLocale must be used within an IntlProvider");
  return ctx.locale;
}
