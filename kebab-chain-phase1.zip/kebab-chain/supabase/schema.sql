-- Minimum schema to run the Home page + Admin foundation delivered in this pass.
-- This is a starting point, not the full platform schema (menu categories, coupons,
-- reservations, delivery zones, etc. still need their own tables + RLS policies).

create type staff_role as enum (
  'admin',
  'manager',
  'branch_manager',
  'cashier',
  'kitchen_staff',
  'delivery_staff'
);

create table staff (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  role staff_role not null default 'cashier',
  branch_id uuid, -- references branches(id) once that table exists
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create unique index staff_user_id_idx on staff (user_id);

create table branches (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  address text not null,
  phone text,
  email text,
  opening_hours jsonb, -- e.g. { "mon": "10:00-23:00", ... }
  latitude double precision,
  longitude double precision,
  is_open boolean not null default true,
  created_at timestamptz not null default now()
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references auth.users (id),
  branch_id uuid references branches (id),
  status text not null default 'pending',
  total numeric(10, 2) not null default 0,
  created_at timestamptz not null default now()
);

alter table staff enable row level security;
alter table branches enable row level security;
alter table orders enable row level security;

-- Staff can read their own record (needed for the admin login role check).
create policy "staff can read own record"
  on staff for select
  using (auth.uid() = user_id);

-- Any authenticated staff member can read branches; write access is tightened
-- per-role once the full admin CRUD is built.
create policy "staff can read branches"
  on branches for select
  using (exists (select 1 from staff where staff.user_id = auth.uid() and staff.is_active));

create policy "staff can read orders"
  on orders for select
  using (exists (select 1 from staff where staff.user_id = auth.uid() and staff.is_active));
