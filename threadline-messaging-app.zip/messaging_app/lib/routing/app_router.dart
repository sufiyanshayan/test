import 'package:flutter/material.dart';

import '../screens/auth_screens.dart';
import '../screens/chat_screen.dart';
import '../screens/group_screens.dart';
import '../screens/home_screen.dart';
import '../screens/new_chat_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/settings_screen.dart';

class AppRoutes {
  static const login = '/login';
  static const register = '/register';
  static const home = '/home';
  static const chat = '/chat';
  static const newChat = '/new-chat';
  static const createGroup = '/create-group';
  static const groupInfo = '/group-info';
  static const profile = '/profile';
  static const settings = '/settings';
}

class AppRouter {
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case AppRoutes.register:
        return MaterialPageRoute(builder: (_) => const RegisterScreen());
      case AppRoutes.home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case AppRoutes.chat:
        final args = settings.arguments as ChatScreenArgs;
        return MaterialPageRoute(builder: (_) => ChatScreen(args: args));
      case AppRoutes.newChat:
        return MaterialPageRoute(builder: (_) => const NewChatScreen());
      case AppRoutes.createGroup:
        return MaterialPageRoute(builder: (_) => const CreateGroupScreen());
      case AppRoutes.groupInfo:
        final conversationId = settings.arguments as String;
        return MaterialPageRoute(builder: (_) => GroupInfoScreen(conversationId: conversationId));
      case AppRoutes.profile:
        return MaterialPageRoute(builder: (_) => const ProfileScreen());
      case AppRoutes.settings:
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(body: Center(child: Text('Page not found'))),
        );
    }
  }
}
