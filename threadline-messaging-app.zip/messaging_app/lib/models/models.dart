// Data models — each mirrors a Postgres table 1:1 so fromJson/toJson stay
// trivial. Keep these free of business logic; that lives in services/.

enum ConversationType { direct, group }

ConversationType conversationTypeFromString(String s) =>
    s == 'group' ? ConversationType.group : ConversationType.direct;

enum MessageType { text, image, file, system, voice, location }

MessageType messageTypeFromString(String s) {
  switch (s) {
    case 'image':
      return MessageType.image;
    case 'file':
      return MessageType.file;
    case 'system':
      return MessageType.system;
    case 'voice':
      return MessageType.voice;
    case 'location':
      return MessageType.location;
    default:
      return MessageType.text;
  }
}

enum ReadStatus { sent, delivered, read }

ReadStatus readStatusFromString(String s) {
  switch (s) {
    case 'delivered':
      return ReadStatus.delivered;
    case 'read':
      return ReadStatus.read;
    default:
      return ReadStatus.sent;
  }
}

enum GroupRole { member, admin, owner }

GroupRole groupRoleFromString(String s) {
  switch (s) {
    case 'admin':
      return GroupRole.admin;
    case 'owner':
      return GroupRole.owner;
    default:
      return GroupRole.member;
  }
}

class Profile {
  final String id;
  final String username;
  final String displayName;
  final String? avatarUrl;
  final String about;
  final String status; // 'online' | 'offline'
  final DateTime? lastSeen;

  Profile({
    required this.id,
    required this.username,
    required this.displayName,
    this.avatarUrl,
    this.about = '',
    this.status = 'offline',
    this.lastSeen,
  });

  bool get isOnline => status == 'online';

  factory Profile.fromJson(Map<String, dynamic> json) => Profile(
        id: json['id'] as String,
        username: json['username'] as String,
        displayName: json['display_name'] as String,
        avatarUrl: json['avatar_url'] as String?,
        about: json['about'] as String? ?? '',
        status: json['status'] as String? ?? 'offline',
        lastSeen: json['last_seen'] != null
            ? DateTime.parse(json['last_seen'] as String)
            : null,
      );
}

class Attachment {
  final String id;
  final String messageId;
  final String fileUrl;
  final String? fileName;
  final String? fileType;
  final int? fileSizeBytes;
  final int? width;
  final int? height;

  Attachment({
    required this.id,
    required this.messageId,
    required this.fileUrl,
    this.fileName,
    this.fileType,
    this.fileSizeBytes,
    this.width,
    this.height,
  });

  factory Attachment.fromJson(Map<String, dynamic> json) => Attachment(
        id: json['id'] as String,
        messageId: json['message_id'] as String,
        fileUrl: json['file_url'] as String,
        fileName: json['file_name'] as String?,
        fileType: json['file_type'] as String?,
        fileSizeBytes: json['file_size_bytes'] as int?,
        width: json['width'] as int?,
        height: json['height'] as int?,
      );
}

class Message {
  final String id;
  final String conversationId;
  final String? senderId;
  final MessageType type;
  final String? content;
  final String? replyToMessageId;
  final bool isDeleted;
  final DateTime createdAt;
  final List<Attachment> attachments;
  final ReadStatus? myReadStatus; // status of this message for the viewer

  Message({
    required this.id,
    required this.conversationId,
    required this.senderId,
    required this.type,
    this.content,
    this.replyToMessageId,
    this.isDeleted = false,
    required this.createdAt,
    this.attachments = const [],
    this.myReadStatus,
  });

  factory Message.fromJson(Map<String, dynamic> json) => Message(
        id: json['id'] as String,
        conversationId: json['conversation_id'] as String,
        senderId: json['sender_id'] as String?,
        type: messageTypeFromString(json['message_type'] as String? ?? 'text'),
        content: json['content'] as String?,
        replyToMessageId: json['reply_to_message_id'] as String?,
        isDeleted: json['is_deleted'] as bool? ?? false,
        createdAt: DateTime.parse(json['created_at'] as String),
        attachments: (json['message_attachments'] as List<dynamic>? ?? [])
            .map((a) => Attachment.fromJson(a as Map<String, dynamic>))
            .toList(),
      );
}

class Conversation {
  final String id;
  final ConversationType type;
  final DateTime? lastMessageAt;
  final String? lastMessagePreview;
  // Populated client-side for display:
  final String title;
  final String? photoUrl;
  final int unreadCount;

  Conversation({
    required this.id,
    required this.type,
    this.lastMessageAt,
    this.lastMessagePreview,
    required this.title,
    this.photoUrl,
    this.unreadCount = 0,
  });

  factory Conversation.fromJson(Map<String, dynamic> json,
      {required String title, String? photoUrl, int unreadCount = 0}) {
    return Conversation(
      id: json['id'] as String,
      type: conversationTypeFromString(json['type'] as String),
      lastMessageAt: json['last_message_at'] != null
          ? DateTime.parse(json['last_message_at'] as String)
          : null,
      lastMessagePreview: json['preview'] as String?,
      title: title,
      photoUrl: photoUrl,
      unreadCount: unreadCount,
    );
  }
}

class GroupInfo {
  final String conversationId;
  final String name;
  final String description;
  final String? photoUrl;
  final String? createdBy;

  GroupInfo({
    required this.conversationId,
    required this.name,
    this.description = '',
    this.photoUrl,
    this.createdBy,
  });

  factory GroupInfo.fromJson(Map<String, dynamic> json) => GroupInfo(
        conversationId: json['conversation_id'] as String,
        name: json['name'] as String,
        description: json['description'] as String? ?? '',
        photoUrl: json['photo_url'] as String?,
        createdBy: json['created_by'] as String?,
      );
}

class GroupMemberInfo {
  final String userId;
  final GroupRole role;
  final Profile? profile;

  GroupMemberInfo({required this.userId, required this.role, this.profile});

  factory GroupMemberInfo.fromJson(Map<String, dynamic> json) => GroupMemberInfo(
        userId: json['user_id'] as String,
        role: groupRoleFromString(json['role'] as String? ?? 'member'),
        profile: json['profiles'] != null
            ? Profile.fromJson(json['profiles'] as Map<String, dynamic>)
            : null,
      );
}
