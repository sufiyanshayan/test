import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/config.dart';
import '../core/theme.dart';
import '../models/models.dart';
import 'common_widgets.dart';

/// Chat header with Voice/Video call buttons that exist in the UI per the
/// architecture but are disabled in V1 (FeatureFlags.callingEnabled).
class ChatHeader extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String? photoUrl;
  final String subtitle; // "online" / "last seen ..." / "N members"
  final VoidCallback onTitleTap;

  const ChatHeader({
    super.key,
    required this.title,
    this.photoUrl,
    required this.subtitle,
    required this.onTitleTap,
  });

  void _showCallingUnavailable(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Calling unavailable'),
        content: const Text('Calling is currently unavailable.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBar(
      titleSpacing: 0,
      title: InkWell(
        onTap: onTitleTap,
        child: Row(
          children: [
            AppAvatar(url: photoUrl, fallbackText: title, radius: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(title, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
                  Text(subtitle,
                      style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.call),
          color: FeatureFlags.callingEnabled ? null : Theme.of(context).disabledColor,
          onPressed: () => FeatureFlags.callingEnabled
              ? null // wired up in V3
              : _showCallingUnavailable(context),
        ),
        IconButton(
          icon: const Icon(Icons.videocam),
          color: FeatureFlags.callingEnabled ? null : Theme.of(context).disabledColor,
          onPressed: () => FeatureFlags.callingEnabled
              ? null // wired up in V3
              : _showCallingUnavailable(context),
        ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

class ChatBubble extends StatelessWidget {
  final Message message;
  final bool isMine;
  final String? senderName; // shown in group chats for others' messages
  final Message? replyPreview;
  final VoidCallback? onDelete;

  const ChatBubble({
    super.key,
    required this.message,
    required this.isMine,
    this.senderName,
    this.replyPreview,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (message.type == MessageType.system) {
      return Center(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: Theme.of(context).hintColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(message.content ?? '', style: const TextStyle(fontSize: 12)),
        ),
      );
    }

    final bubbleColor = isMine
        ? (isDark ? AppColors.bubbleMineDark : AppColors.bubbleMineLight)
        : (isDark ? AppColors.bubbleTheirsDark : AppColors.bubbleTheirsLight);

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: isMine && onDelete != null
            ? () => _showDeleteSheet(context)
            : null,
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (senderName != null && !isMine)
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: Text(senderName!,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Theme.of(context).colorScheme.primary)),
                ),
              if (replyPreview != null) _ReplyQuote(message: replyPreview!),
              if (message.isDeleted)
                Text('This message was deleted',
                    style: TextStyle(
                        fontStyle: FontStyle.italic, color: Theme.of(context).hintColor))
              else if (message.type == MessageType.text)
                Text(message.content ?? '')
              else if (message.type == MessageType.image)
                _ImageBubbleContent(message: message)
              else
                _FileBubbleContent(message: message),
              const SizedBox(height: 2),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(DateFormat.Hm().format(message.createdAt.toLocal()),
                      style: TextStyle(fontSize: 10, color: Theme.of(context).hintColor)),
                  if (isMine) ...[
                    const SizedBox(width: 4),
                    Icon(
                      message.myReadStatus == ReadStatus.read
                          ? Icons.done_all
                          : message.myReadStatus == ReadStatus.delivered
                              ? Icons.done_all
                              : Icons.done,
                      size: 14,
                      color: message.myReadStatus == ReadStatus.read
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).hintColor,
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showDeleteSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ListTile(
          leading: const Icon(Icons.delete_outline),
          title: const Text('Delete message'),
          onTap: () {
            Navigator.pop(context);
            onDelete?.call();
          },
        ),
      ),
    );
  }
}

class _ReplyQuote extends StatelessWidget {
  final Message message;
  const _ReplyQuote({required this.message});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: Theme.of(context).colorScheme.primary, width: 3)),
      ),
      child: Text(
        message.type == MessageType.text ? (message.content ?? '') : '📎 attachment',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor),
      ),
    );
  }
}

class _ImageBubbleContent extends StatelessWidget {
  final Message message;
  const _ImageBubbleContent({required this.message});
  @override
  Widget build(BuildContext context) {
    if (message.attachments.isEmpty) return const SizedBox.shrink();
    final url = message.attachments.first.fileUrl;
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Image.network(url, fit: BoxFit.cover, width: 220, height: 220,
          errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
    );
  }
}

class _FileBubbleContent extends StatelessWidget {
  final Message message;
  const _FileBubbleContent({required this.message});
  @override
  Widget build(BuildContext context) {
    if (message.attachments.isEmpty) return const SizedBox.shrink();
    final a = message.attachments.first;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.insert_drive_file_outlined),
        const SizedBox(width: 6),
        Flexible(child: Text(a.fileName ?? 'File', overflow: TextOverflow.ellipsis)),
      ],
    );
  }
}

class TypingIndicator extends StatelessWidget {
  final bool visible;
  const TypingIndicator({super.key, required this.visible});
  @override
  Widget build(BuildContext context) {
    if (!visible) return const SizedBox(height: 20);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      child: Text('typing…', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
    );
  }
}

class MessageInput extends StatefulWidget {
  final Message? replyingTo;
  final VoidCallback? onCancelReply;
  final void Function(String text) onSend;
  final VoidCallback onPickImage;
  final VoidCallback onPickFile;
  final void Function(bool isTyping) onTypingChanged;

  const MessageInput({
    super.key,
    this.replyingTo,
    this.onCancelReply,
    required this.onSend,
    required this.onPickImage,
    required this.onPickFile,
    required this.onTypingChanged,
  });

  @override
  State<MessageInput> createState() => _MessageInputState();
}

class _MessageInputState extends State<MessageInput> {
  final _controller = TextEditingController();
  bool _wasTyping = false;

  void _handleChange(String text) {
    final isTyping = text.trim().isNotEmpty;
    if (isTyping != _wasTyping) {
      _wasTyping = isTyping;
      widget.onTypingChanged(isTyping);
    }
  }

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    widget.onSend(text);
    _controller.clear();
    widget.onTypingChanged(false);
    _wasTyping = false;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (widget.replyingTo != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              color: Theme.of(context).hintColor.withOpacity(0.08),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Replying to: ${widget.replyingTo!.content ?? "attachment"}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 16),
                    onPressed: widget.onCancelReply,
                  ),
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Row(
              children: [
                IconButton(icon: const Icon(Icons.image_outlined), onPressed: widget.onPickImage),
                IconButton(
                    icon: const Icon(Icons.attach_file_outlined), onPressed: widget.onPickFile),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onChanged: _handleChange,
                    minLines: 1,
                    maxLines: 5,
                    decoration: const InputDecoration(hintText: 'Message'),
                  ),
                ),
                const SizedBox(width: 4),
                IconButton(
                  icon: const Icon(Icons.send_rounded),
                  color: Theme.of(context).colorScheme.primary,
                  onPressed: _send,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
