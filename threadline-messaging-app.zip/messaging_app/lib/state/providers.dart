import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/models.dart';
import '../services/auth_service.dart';
import '../services/chat_service.dart';
import '../services/realtime_service.dart';
import '../services/storage_service.dart';

final supabaseClientProvider = Provider<SupabaseClient>((ref) => Supabase.instance.client);

final authServiceProvider =
    Provider<AuthService>((ref) => AuthService(ref.watch(supabaseClientProvider)));
final chatServiceProvider =
    Provider<ChatService>((ref) => ChatService(ref.watch(supabaseClientProvider)));
final storageServiceProvider =
    Provider<StorageService>((ref) => StorageService(ref.watch(supabaseClientProvider)));
final realtimeServiceProvider =
    Provider<RealtimeService>((ref) => RealtimeService(ref.watch(supabaseClientProvider)));

/// Emits whenever auth state changes (login/logout/token refresh).
final authStateProvider = StreamProvider<AuthState>((ref) {
  return ref.watch(authServiceProvider).onAuthStateChange;
});

/// The signed-in user's own profile.
final myProfileProvider = FutureProvider<Profile>((ref) {
  ref.watch(authStateProvider); // re-fetch on auth changes
  return ref.watch(authServiceProvider).fetchMyProfile();
});

/// Chat list (Home screen). Re-run with `ref.invalidate(chatListProvider)`
/// after sending a message or on a conversation_members realtime event.
final chatListProvider = FutureProvider<List<Conversation>>((ref) {
  return ref.watch(chatServiceProvider).fetchChatList();
});

/// Paginated messages for one open conversation, newest-first.
class ConversationMessagesNotifier extends StateNotifier<AsyncValue<List<Message>>> {
  final ChatService _chatService;
  final String conversationId;
  bool _hasMore = true;
  bool _loadingMore = false;

  ConversationMessagesNotifier(this._chatService, this.conversationId)
      : super(const AsyncValue.loading()) {
    _loadInitial();
  }

  Future<void> _loadInitial() async {
    state = const AsyncValue.loading();
    try {
      final messages = await _chatService.fetchMessages(conversationId);
      state = AsyncValue.data(messages);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> loadMore() async {
    if (_loadingMore || !_hasMore) return;
    final current = state.value ?? [];
    if (current.isEmpty) return;
    _loadingMore = true;
    try {
      final older = await _chatService.fetchMessages(
        conversationId,
        before: current.last.createdAt,
      );
      if (older.isEmpty) _hasMore = false;
      state = AsyncValue.data([...current, ...older]);
    } finally {
      _loadingMore = false;
    }
  }

  void prependIncoming(Message message) {
    final current = state.value ?? [];
    if (current.any((m) => m.id == message.id)) return;
    state = AsyncValue.data([message, ...current]);
  }

  void replaceMessage(Message message) {
    final current = state.value ?? [];
    state = AsyncValue.data([
      for (final m in current) if (m.id == message.id) message else m,
    ]);
  }
}

final conversationMessagesProvider = StateNotifierProvider.family<
    ConversationMessagesNotifier, AsyncValue<List<Message>>, String>((ref, conversationId) {
  return ConversationMessagesNotifier(ref.watch(chatServiceProvider), conversationId);
});

/// Typing state per conversation: set of user IDs currently typing.
class TypingNotifier extends StateNotifier<Set<String>> {
  TypingNotifier() : super({});
  void setTyping(String userId, bool isTyping) {
    state = isTyping ? {...state, userId} : {...state}..remove(userId);
  }
}

final typingProvider =
    StateNotifierProvider.family<TypingNotifier, Set<String>, String>((ref, conversationId) {
  return TypingNotifier();
});
