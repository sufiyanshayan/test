import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/config.dart';
import 'app.dart';

/// Entry point.
///
/// Supabase URL/anon key are read from --dart-define at build time so no
/// secret ever lives in source control. See README.md for the run command.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: SupabaseConfig.url,
    anonKey: SupabaseConfig.anonKey,
    // Keep sessions on-device; SDK auto-refreshes tokens.
    authFlowType: AuthFlowType.pkce,
  );

  runApp(const ProviderScope(child: MessagingApp()));
}

/// Global accessor for the singleton Supabase client.
final supabase = Supabase.instance.client;
