import 'package:flutter/material.dart';

/// Original color identity for "Threadline" — deliberately not WhatsApp
/// green. A deep indigo/teal pairing with a warm accent for unread badges.
class AppColors {
  static const Color primary = Color(0xFF3A5AFF); // indigo-blue
  static const Color primaryDark = Color(0xFF7C93FF);
  static const Color accent = Color(0xFF00C2A8); // teal accent
  static const Color unread = Color(0xFFFF6B4A); // warm badge

  static const Color bgLight = Color(0xFFF7F8FC);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color bgDark = Color(0xFF0F1220);
  static const Color surfaceDark = Color(0xFF1A1E2E);

  static const Color bubbleMineLight = Color(0xFFE7ECFF);
  static const Color bubbleTheirsLight = Color(0xFFFFFFFF);
  static const Color bubbleMineDark = Color(0xFF3A4370);
  static const Color bubbleTheirsDark = Color(0xFF232840);
}

class AppTheme {
  static ThemeData get light => _base(
        brightness: Brightness.light,
        bg: AppColors.bgLight,
        surface: AppColors.surfaceLight,
        primary: AppColors.primary,
      );

  static ThemeData get dark => _base(
        brightness: Brightness.dark,
        bg: AppColors.bgDark,
        surface: AppColors.surfaceDark,
        primary: AppColors.primaryDark,
      );

  static ThemeData _base({
    required Brightness brightness,
    required Color bg,
    required Color surface,
    required Color primary,
  }) {
    final base = ThemeData(brightness: brightness, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: base.colorScheme.copyWith(
        primary: primary,
        secondary: AppColors.accent,
        surface: surface,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: surface,
        foregroundColor: brightness == Brightness.dark ? Colors.white : Colors.black87,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: brightness == Brightness.dark ? Colors.white : Colors.black87,
        ),
      ),
      textTheme: base.textTheme.apply(
        fontFamily: 'Roboto',
        bodyColor: brightness == Brightness.dark ? Colors.white : Colors.black87,
        displayColor: brightness == Brightness.dark ? Colors.white : Colors.black87,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: brightness == Brightness.dark
            ? Colors.white.withOpacity(0.06)
            : Colors.black.withOpacity(0.04),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}
