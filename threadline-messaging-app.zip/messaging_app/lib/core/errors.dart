import 'package:postgrest/postgrest.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// A user-safe error. Never show raw Postgres/Supabase errors in the UI —
/// always convert through [mapErrorToMessage] first.
class AppException implements Exception {
  final String message;
  AppException(this.message);
  @override
  String toString() => message;
}

String mapErrorToMessage(Object error) {
  if (error is AuthException) {
    final msg = error.message.toLowerCase();
    if (msg.contains('invalid login credentials')) {
      return 'Incorrect email or password.';
    }
    if (msg.contains('already registered') || msg.contains('duplicate')) {
      return 'An account with this email already exists.';
    }
    if (msg.contains('email not confirmed')) {
      return 'Please confirm your email before logging in.';
    }
    return 'Authentication failed. Please try again.';
  }
  if (error is PostgrestException) {
    if (error.code == '23505') return 'That value is already taken.';
    if (error.code == '42501' || error.code == 'PGRST301') {
      return "You don't have permission to do that.";
    }
    return 'Something went wrong. Please try again.';
  }
  if (error is StorageException) {
    return 'Upload failed. Please check the file and try again.';
  }
  final s = error.toString().toLowerCase();
  if (s.contains('socketexception') || s.contains('network')) {
    return 'No internet connection.';
  }
  return 'Something went wrong. Please try again.';
}

class Validators {
  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return 'Email is required';
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim());
    return ok ? null : 'Enter a valid email';
  }

  static String? password(String? value) {
    if (value == null || value.length < 8) {
      return 'Password must be at least 8 characters';
    }
    return null;
  }

  static String? username(String? value) {
    if (value == null || value.trim().isEmpty) return 'Username is required';
    final ok = RegExp(r'^[a-zA-Z0-9_.]{3,20}$').hasMatch(value.trim());
    return ok ? null : '3-20 chars: letters, numbers, _ or .';
  }

  static String? notEmpty(String? value, {String field = 'This field'}) {
    if (value == null || value.trim().isEmpty) return '$field is required';
    return null;
  }
}
