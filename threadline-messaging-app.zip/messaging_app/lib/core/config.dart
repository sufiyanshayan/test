/// Supabase credentials — never hard-code these.
/// Run with:
/// flutter run \
///   --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
///   --dart-define=SUPABASE_ANON_KEY=eyJhbGciOi...
class SupabaseConfig {
  static const String url = String.fromEnvironment('SUPABASE_URL');
  static const String anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
}

/// Central place to toggle features that aren't ready yet.
/// V1 rule: calling exists in the UI but is always disabled.
class FeatureFlags {
  static const bool callingEnabled = false; // flip in V3, wire in WebRTC
  static const bool voiceMessagesEnabled = false; // V2
  static const bool disappearingMessagesEnabled = false; // V5
}

class StorageBuckets {
  static const String avatars = 'avatars';
  static const String chatMedia = 'chat-media';
}

class AppLimits {
  static const int maxImageBytes = 10 * 1024 * 1024; // 10 MB
  static const int maxFileBytes = 25 * 1024 * 1024; // 25 MB
  static const int messagePageSize = 30;
}
