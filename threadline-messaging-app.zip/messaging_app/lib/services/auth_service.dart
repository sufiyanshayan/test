import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/errors.dart';
import '../models/models.dart';

class AuthService {
  final SupabaseClient _client;
  AuthService(this._client);

  User? get currentUser => _client.auth.currentUser;
  Stream<AuthState> get onAuthStateChange => _client.auth.onAuthStateChange;

  Future<void> register({
    required String email,
    required String password,
    required String username,
    required String displayName,
  }) async {
    try {
      final res = await _client.auth.signUp(email: email, password: password);
      final user = res.user;
      if (user == null) throw AppException('Registration failed.');
      // profiles row is auto-created by the on_auth_user_created trigger
      // (see supabase/migrations/0001_init.sql); we just fill in the rest.
      await _client.from('profiles').update({
        'username': username,
        'display_name': displayName,
      }).eq('id', user.id);
    } on AuthException catch (e) {
      throw AppException(mapErrorToMessage(e));
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> login({required String email, required String password}) async {
    try {
      await _client.auth.signInWithPassword(email: email, password: password);
      await setOnlineStatus(true);
    } on AuthException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> logout() async {
    try {
      await setOnlineStatus(false);
    } catch (_) {
      // best-effort — still sign out even if the status update fails
    }
    await _client.auth.signOut();
  }

  Future<void> setOnlineStatus(bool online) async {
    final uid = currentUser?.id;
    if (uid == null) return;
    await _client.from('profiles').update({
      'status': online ? 'online' : 'offline',
      'last_seen': DateTime.now().toIso8601String(),
    }).eq('id', uid);
  }

  Future<Profile> fetchMyProfile() async {
    final uid = currentUser?.id;
    if (uid == null) throw AppException('Not signed in.');
    final row = await _client.from('profiles').select().eq('id', uid).single();
    return Profile.fromJson(row);
  }

  Future<Profile> fetchProfile(String userId) async {
    final row = await _client.from('profiles').select().eq('id', userId).single();
    return Profile.fromJson(row);
  }

  Future<List<Profile>> searchProfiles(String query) async {
    if (query.trim().isEmpty) return [];
    final rows = await _client
        .from('profiles')
        .select()
        .ilike('username', '%${query.trim()}%')
        .neq('id', currentUser?.id ?? '')
        .limit(20);
    return (rows as List).map((r) => Profile.fromJson(r)).toList();
  }

  Future<void> updateMyProfile({
    String? displayName,
    String? about,
    String? avatarUrl,
  }) async {
    final uid = currentUser?.id;
    if (uid == null) throw AppException('Not signed in.');
    final updates = <String, dynamic>{};
    if (displayName != null) updates['display_name'] = displayName;
    if (about != null) updates['about'] = about;
    if (avatarUrl != null) updates['avatar_url'] = avatarUrl;
    if (updates.isEmpty) return;
    try {
      await _client.from('profiles').update(updates).eq('id', uid);
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }
}
