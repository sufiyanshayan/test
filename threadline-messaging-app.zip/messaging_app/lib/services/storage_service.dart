import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../core/config.dart';
import '../core/errors.dart';

class StorageService {
  final SupabaseClient _client;
  StorageService(this._client);

  String get _myId => _client.auth.currentUser!.id;
  static const _uuid = Uuid();

  Future<String> uploadAvatar(File file) async {
    _validateSize(await file.length(), AppLimits.maxImageBytes);
    final bytes = await _compressIfImage(file);
    final path = '$_myId/${_uuid.v4()}.jpg';
    try {
      await _client.storage.from(StorageBuckets.avatars).uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true),
          );
      return _client.storage.from(StorageBuckets.avatars).getPublicUrl(path);
    } on StorageException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  /// Path convention: chat-media/{conversationId}/{uuid}-{filename}
  /// The {conversationId} prefix is what the RLS storage policy checks
  /// against conversation_members, so it must come first.
  Future<Map<String, dynamic>> uploadChatMedia({
    required String conversationId,
    required File file,
    required String fileName,
    required bool isImage,
  }) async {
    final size = await file.length();
    _validateSize(size, isImage ? AppLimits.maxImageBytes : AppLimits.maxFileBytes);

    final bytes = isImage ? await _compressIfImage(file) : await file.readAsBytes();
    final path = '$conversationId/${_uuid.v4()}-$fileName';

    try {
      await _client.storage.from(StorageBuckets.chatMedia).uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(
              contentType: isImage ? 'image/jpeg' : null,
              upsert: false,
            ),
          );
      // chat-media is private; generate a signed URL valid for a long window.
      final signedUrl = await _client.storage
          .from(StorageBuckets.chatMedia)
          .createSignedUrl(path, 60 * 60 * 24 * 7); // 7 days
      return {
        'url': signedUrl,
        'path': path,
        'size': bytes.length,
      };
    } on StorageException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  void _validateSize(int bytes, int max) {
    if (bytes > max) {
      throw AppException(
          'File is too large (max ${(max / (1024 * 1024)).toStringAsFixed(0)} MB).');
    }
  }

  Future<Uint8List> _compressIfImage(File file) async {
    final ext = file.path.split('.').last.toLowerCase();
    if (!['jpg', 'jpeg', 'png', 'webp'].contains(ext)) {
      return file.readAsBytes();
    }
    final compressed = await FlutterImageCompress.compressWithFile(
      file.path,
      quality: 80,
      minWidth: 1280,
      minHeight: 1280,
    );
    return compressed ?? file.readAsBytes();
  }
}
