import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/config.dart';
import '../core/errors.dart';
import '../models/models.dart';

class ChatService {
  final SupabaseClient _client;
  ChatService(this._client);

  String get _myId => _client.auth.currentUser!.id;

  // ---------------- Conversations ----------------

  /// Finds an existing direct conversation between me and [otherUserId],
  /// or creates one. Prevents duplicate 1:1 threads.
  Future<String> getOrCreateDirectConversation(String otherUserId) async {
    final mine = await _client
        .from('conversation_members')
        .select('conversation_id, conversations!inner(type)')
        .eq('user_id', _myId)
        .eq('conversations.type', 'direct');

    for (final row in (mine as List)) {
      final convoId = row['conversation_id'] as String;
      final members = await _client
          .from('conversation_members')
          .select('user_id')
          .eq('conversation_id', convoId);
      final ids = (members as List).map((m) => m['user_id'] as String).toSet();
      if (ids.length == 2 && ids.contains(otherUserId)) {
        return convoId;
      }
    }

    try {
      final convo = await _client
          .from('conversations')
          .insert({'type': 'direct', 'created_by': _myId})
          .select()
          .single();
      final convoId = convo['id'] as String;
      await _client.from('conversation_members').insert([
        {'conversation_id': convoId, 'user_id': _myId},
        {'conversation_id': convoId, 'user_id': otherUserId},
      ]);
      return convoId;
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  /// Chat list: conversations I'm a member of, newest activity first,
  /// with a resolved title (other user's name, or group name).
  Future<List<Conversation>> fetchChatList() async {
    final rows = await _client
        .from('conversation_members')
        .select('conversations!inner(id, type, last_message_at, '
            'groups(name, photo_url), '
            'messages!conversations_last_message_id_fkey(content, message_type))')
        .eq('user_id', _myId)
        .order('last_message_at', referencedTable: 'conversations', ascending: false);

    final result = <Conversation>[];
    for (final row in (rows as List)) {
      final c = row['conversations'] as Map<String, dynamic>;
      final type = conversationTypeFromString(c['type'] as String);
      String title;
      String? photoUrl;
      if (type == ConversationType.group) {
        final g = c['groups'] as Map<String, dynamic>?;
        title = g?['name'] as String? ?? 'Group';
        photoUrl = g?['photo_url'] as String?;
      } else {
        final other = await _otherMemberProfile(c['id'] as String);
        title = other?.displayName ?? 'Unknown';
        photoUrl = other?.avatarUrl;
      }
      final lastMsg = c['messages'] as Map<String, dynamic>?;
      final preview = lastMsg == null
          ? null
          : (lastMsg['message_type'] == 'text'
              ? lastMsg['content'] as String?
              : '📎 ${lastMsg['message_type']}');

      result.add(Conversation.fromJson(
        {
          'id': c['id'],
          'type': c['type'],
          'last_message_at': c['last_message_at'],
          'preview': preview,
        },
        title: title,
        photoUrl: photoUrl,
      ));
    }
    return result;
  }

  Future<Profile?> _otherMemberProfile(String conversationId) async {
    final rows = await _client
        .from('conversation_members')
        .select('user_id, profiles(*)')
        .eq('conversation_id', conversationId)
        .neq('user_id', _myId)
        .limit(1);
    if ((rows as List).isEmpty) return null;
    final p = rows.first['profiles'] as Map<String, dynamic>?;
    return p == null ? null : Profile.fromJson(p);
  }

  // ---------------- Messages ----------------

  /// Keyset-paginated message fetch, newest page first.
  Future<List<Message>> fetchMessages(
    String conversationId, {
    DateTime? before,
    int limit = AppLimits.messagePageSize,
  }) async {
    var query = _client
        .from('messages')
        .select('*, message_attachments(*)')
        .eq('conversation_id', conversationId);
    if (before != null) {
      query = query.lt('created_at', before.toIso8601String());
    }
    final rows = await query.order('created_at', ascending: false).limit(limit);
    return (rows as List).map((r) => Message.fromJson(r)).toList();
  }

  Future<Message> sendTextMessage({
    required String conversationId,
    required String content,
    String? replyToMessageId,
  }) async {
    try {
      final row = await _client
          .from('messages')
          .insert({
            'conversation_id': conversationId,
            'sender_id': _myId,
            'message_type': 'text',
            'content': content,
            'reply_to_message_id': replyToMessageId,
          })
          .select()
          .single();
      await _updateConversationPointer(conversationId, row['id'] as String);
      return Message.fromJson(row);
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  /// Inserts a message row for an already-uploaded attachment
  /// (call storage upload first, then this).
  Future<Message> sendAttachmentMessage({
    required String conversationId,
    required MessageType type, // image | file
    required String fileUrl,
    String? fileName,
    String? fileType,
    int? fileSizeBytes,
    int? width,
    int? height,
    String? caption,
  }) async {
    try {
      final msgRow = await _client
          .from('messages')
          .insert({
            'conversation_id': conversationId,
            'sender_id': _myId,
            'message_type': type.name,
            'content': caption,
          })
          .select()
          .single();
      final messageId = msgRow['id'] as String;
      await _client.from('message_attachments').insert({
        'message_id': messageId,
        'file_url': fileUrl,
        'file_name': fileName,
        'file_type': fileType,
        'file_size_bytes': fileSizeBytes,
        'width': width,
        'height': height,
      });
      await _updateConversationPointer(conversationId, messageId);
      return Message.fromJson(msgRow);
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> _updateConversationPointer(String conversationId, String messageId) async {
    await _client.from('conversations').update({
      'last_message_id': messageId,
      'last_message_at': DateTime.now().toIso8601String(),
    }).eq('id', conversationId);
  }

  Future<void> deleteMessage(String messageId) async {
    try {
      await _client.from('messages').update({
        'is_deleted': true,
        'content': null,
        'deleted_at': DateTime.now().toIso8601String(),
      }).eq('id', messageId).eq('sender_id', _myId);
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> markStatus(String messageId, ReadStatus status) async {
    await _client.from('message_reads').upsert({
      'message_id': messageId,
      'user_id': _myId,
      'status': status.name,
      'status_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Message>> searchMessages(String conversationId, String query) async {
    if (query.trim().isEmpty) return [];
    final rows = await _client
        .from('messages')
        .select('*, message_attachments(*)')
        .eq('conversation_id', conversationId)
        .eq('is_deleted', false)
        .ilike('content', '%${query.trim()}%')
        .order('created_at', ascending: false)
        .limit(50);
    return (rows as List).map((r) => Message.fromJson(r)).toList();
  }

  // ---------------- Groups ----------------

  Future<String> createGroup({
    required String name,
    String description = '',
    String? photoUrl,
    required List<String> memberIds,
  }) async {
    try {
      final convo = await _client
          .from('conversations')
          .insert({'type': 'group', 'created_by': _myId})
          .select()
          .single();
      final convoId = convo['id'] as String;

      await _client.from('groups').insert({
        'conversation_id': convoId,
        'name': name,
        'description': description,
        'photo_url': photoUrl,
        'created_by': _myId,
      });

      final allMembers = {_myId, ...memberIds}.toList();
      await _client.from('conversation_members').insert(
          allMembers.map((id) => {'conversation_id': convoId, 'user_id': id}).toList());
      await _client.from('group_members').insert([
        {'conversation_id': convoId, 'user_id': _myId, 'role': 'owner'},
        ...memberIds.map((id) => {
              'conversation_id': convoId,
              'user_id': id,
              'role': 'member',
            }),
      ]);
      return convoId;
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<GroupInfo> fetchGroupInfo(String conversationId) async {
    final row =
        await _client.from('groups').select().eq('conversation_id', conversationId).single();
    return GroupInfo.fromJson(row);
  }

  Future<List<GroupMemberInfo>> fetchGroupMembers(String conversationId) async {
    final rows = await _client
        .from('group_members')
        .select('user_id, role, profiles(*)')
        .eq('conversation_id', conversationId);
    return (rows as List).map((r) => GroupMemberInfo.fromJson(r)).toList();
  }

  Future<void> addGroupMember(String conversationId, String userId) async {
    try {
      await _client.from('conversation_members').insert({
        'conversation_id': conversationId,
        'user_id': userId,
      });
      await _client.from('group_members').insert({
        'conversation_id': conversationId,
        'user_id': userId,
        'role': 'member',
      });
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> removeGroupMember(String conversationId, String userId) async {
    try {
      await _client
          .from('group_members')
          .delete()
          .eq('conversation_id', conversationId)
          .eq('user_id', userId);
      await _client
          .from('conversation_members')
          .delete()
          .eq('conversation_id', conversationId)
          .eq('user_id', userId);
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> setMemberRole(String conversationId, String userId, GroupRole role) async {
    try {
      await _client
          .from('group_members')
          .update({'role': role.name})
          .eq('conversation_id', conversationId)
          .eq('user_id', userId);
    } on PostgrestException catch (e) {
      throw AppException(mapErrorToMessage(e));
    }
  }

  Future<void> leaveGroup(String conversationId) async {
    await removeGroupMember(conversationId, _myId);
    await _client.from('messages').insert({
      'conversation_id': conversationId,
      'sender_id': _myId,
      'message_type': 'system',
      'content': 'left the group',
    });
  }
}
