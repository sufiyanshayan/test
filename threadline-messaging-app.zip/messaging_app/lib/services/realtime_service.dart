import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/models.dart';

/// Wraps Supabase Realtime so screens only deal with typed callbacks.
/// One channel per open conversation — subscribed on screen open,
/// unsubscribed on screen close. Chat-list-level updates ride on a
/// single conversation_members subscription that lives for the app session.
class RealtimeService {
  final SupabaseClient _client;
  RealtimeService(this._client);

  final Map<String, RealtimeChannel> _conversationChannels = {};

  /// New/updated/deleted messages for one conversation.
  RealtimeChannel subscribeToConversation({
    required String conversationId,
    required void Function(Message message) onInsert,
    required void Function(Message message) onUpdate,
    required void Function(String typingUserId, bool isTyping) onTyping,
  }) {
    final channel = _client.channel('conversation:$conversationId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'messages',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'conversation_id',
          value: conversationId,
        ),
        callback: (payload) => onInsert(Message.fromJson(payload.newRecord)),
      )
      ..onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'messages',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'conversation_id',
          value: conversationId,
        ),
        callback: (payload) => onUpdate(Message.fromJson(payload.newRecord)),
      )
      // Typing indicator: ephemeral broadcast, never written to Postgres.
      ..onBroadcast(
        event: 'typing',
        callback: (payload) {
          onTyping(payload['user_id'] as String, payload['is_typing'] as bool);
        },
      )
      ..subscribe();

    _conversationChannels[conversationId] = channel;
    return channel;
  }

  Future<void> sendTyping({required String conversationId, required bool isTyping}) async {
    final channel = _conversationChannels[conversationId];
    if (channel == null) return;
    await channel.sendBroadcastMessage(
      event: 'typing',
      payload: {'user_id': _client.auth.currentUser!.id, 'is_typing': isTyping},
    );
  }

  Future<void> unsubscribeFromConversation(String conversationId) async {
    final channel = _conversationChannels.remove(conversationId);
    if (channel != null) await _client.removeChannel(channel);
  }

  // ---------------- Presence ----------------

  RealtimeChannel? _presenceChannel;

  void trackMyPresence() {
    final uid = _client.auth.currentUser?.id;
    if (uid == null) return;
    _presenceChannel = _client.channel('presence:global');
    _presenceChannel!
      ..onPresenceSync((_) {})
      ..subscribe((status, error) async {
        if (status == RealtimeSubscribeStatus.subscribed) {
          await _presenceChannel!.track({'user_id': uid, 'online_at': DateTime.now().toIso8601String()});
        }
      });
  }

  Future<void> stopPresence() async {
    if (_presenceChannel != null) {
      await _client.removeChannel(_presenceChannel!);
      _presenceChannel = null;
    }
  }

  Future<void> disposeAll() async {
    for (final c in _conversationChannels.values) {
      await _client.removeChannel(c);
    }
    _conversationChannels.clear();
    await stopPresence();
  }
}
