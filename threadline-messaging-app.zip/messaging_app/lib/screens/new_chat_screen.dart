import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/models.dart';
import '../routing/app_router.dart';
import '../screens/chat_screen.dart';
import '../state/providers.dart';
import '../widgets/common_widgets.dart';

class NewChatScreen extends ConsumerStatefulWidget {
  const NewChatScreen({super.key});
  @override
  ConsumerState<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends ConsumerState<NewChatScreen> {
  final _query = TextEditingController();
  List<Profile> _results = [];
  bool _loading = false;

  Future<void> _search(String text) async {
    setState(() => _loading = true);
    final results = await ref.read(authServiceProvider).searchProfiles(text);
    if (mounted) setState(() {
      _results = results;
      _loading = false;
    });
  }

  Future<void> _startChat(Profile profile) async {
    final conversationId =
        await ref.read(chatServiceProvider).getOrCreateDirectConversation(profile.id);
    if (!mounted) return;
    Navigator.pushReplacementNamed(
      context,
      AppRoutes.chat,
      arguments: ChatScreenArgs(
        conversationId: conversationId,
        title: profile.displayName,
        photoUrl: profile.avatarUrl,
        isGroup: false,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _query,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Search by username', border: InputBorder.none),
          onChanged: _search,
        ),
      ),
      body: _loading
          ? const LoadingView()
          : _results.isEmpty
              ? const EmptyView(icon: Icons.search, title: 'Search for someone to chat with')
              : ListView.builder(
                  itemCount: _results.length,
                  itemBuilder: (context, i) {
                    final p = _results[i];
                    return ListTile(
                      leading: AppAvatar(url: p.avatarUrl, fallbackText: p.displayName),
                      title: Text(p.displayName),
                      subtitle: Text('@${p.username}'),
                      onTap: () => _startChat(p),
                    );
                  },
                ),
    );
  }
}
