import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../core/errors.dart';
import '../models/models.dart';
import '../routing/app_router.dart';
import '../screens/chat_screen.dart';
import '../state/providers.dart';
import '../widgets/common_widgets.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chatList = ref.watch(chatListProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chats'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.pushNamed(context, AppRoutes.profile),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.pushNamed(context, AppRoutes.settings),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(chatListProvider),
        child: chatList.when(
          loading: () => const LoadingView(),
          error: (e, _) => ErrorView(
            message: e is AppException ? e.message : 'Could not load chats.',
            onRetry: () => ref.invalidate(chatListProvider),
          ),
          data: (conversations) {
            if (conversations.isEmpty) {
              return const EmptyView(
                icon: Icons.chat_bubble_outline,
                title: 'No conversations yet',
                subtitle: 'Tap + to start a new chat or create a group',
              );
            }
            return ListView.separated(
              itemCount: conversations.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final c = conversations[i];
                return ListTile(
                  leading: AppAvatar(url: c.photoUrl, fallbackText: c.title),
                  title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    c.lastMessagePreview ?? 'No messages yet',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: c.lastMessageAt != null
                      ? Text(DateFormat.Hm().format(c.lastMessageAt!.toLocal()),
                          style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))
                      : null,
                  onTap: () => Navigator.pushNamed(
                    context,
                    AppRoutes.chat,
                    arguments: ChatScreenArgs(
                      conversationId: c.id,
                      title: c.title,
                      photoUrl: c.photoUrl,
                      isGroup: c.type == ConversationType.group,
                    ),
                  ).then((_) => ref.invalidate(chatListProvider)),
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showNewChatSheet(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showNewChatSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.person_add_alt_outlined),
              title: const Text('New chat'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, AppRoutes.newChat);
              },
            ),
            ListTile(
              leading: const Icon(Icons.group_add_outlined),
              title: const Text('New group'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, AppRoutes.createGroup);
              },
            ),
          ],
        ),
      ),
    );
  }
}
