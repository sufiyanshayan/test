import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../core/errors.dart';
import '../models/models.dart';
import '../routing/app_router.dart';
import '../state/providers.dart';
import '../widgets/chat_widgets.dart';
import '../widgets/common_widgets.dart';

class ChatScreenArgs {
  final String conversationId;
  final String title;
  final String? photoUrl;
  final bool isGroup;
  ChatScreenArgs({
    required this.conversationId,
    required this.title,
    this.photoUrl,
    required this.isGroup,
  });
}

class ChatScreen extends ConsumerStatefulWidget {
  final ChatScreenArgs args;
  const ChatScreen({super.key, required this.args});

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final _scrollController = ScrollController();
  final _picker = ImagePicker();
  Message? _replyingTo;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) => _subscribe());
  }

  void _onScroll() {
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 200) {
      ref.read(conversationMessagesProvider(widget.args.conversationId).notifier).loadMore();
    }
  }

  void _subscribe() {
    final notifier = ref.read(conversationMessagesProvider(widget.args.conversationId).notifier);
    final typingNotifier = ref.read(typingProvider(widget.args.conversationId).notifier);
    ref.read(realtimeServiceProvider).subscribeToConversation(
          conversationId: widget.args.conversationId,
          onInsert: (message) {
            notifier.prependIncoming(message);
            final myId = ref.read(supabaseClientProvider).auth.currentUser?.id;
            if (message.senderId != myId) {
              ref.read(chatServiceProvider).markStatus(message.id, ReadStatus.delivered);
              ref.read(chatServiceProvider).markStatus(message.id, ReadStatus.read);
            }
          },
          onUpdate: notifier.replaceMessage,
          onTyping: (userId, isTyping) {
            final myId = ref.read(supabaseClientProvider).auth.currentUser?.id;
            if (userId != myId) typingNotifier.setTyping(userId, isTyping);
          },
        );
  }

  @override
  void dispose() {
    ref.read(realtimeServiceProvider).unsubscribeFromConversation(widget.args.conversationId);
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _send(String text) async {
    try {
      await ref.read(chatServiceProvider).sendTextMessage(
            conversationId: widget.args.conversationId,
            content: text,
            replyToMessageId: _replyingTo?.id,
          );
      setState(() => _replyingTo = null);
    } catch (e) {
      _showError(e);
    }
  }

  Future<void> _pickImage() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;
    await _uploadAndSend(File(picked.path), picked.name, isImage: true);
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null || result.files.single.path == null) return;
    final file = File(result.files.single.path!);
    await _uploadAndSend(file, result.files.single.name, isImage: false);
  }

  Future<void> _uploadAndSend(File file, String fileName, {required bool isImage}) async {
    try {
      final uploaded = await ref.read(storageServiceProvider).uploadChatMedia(
            conversationId: widget.args.conversationId,
            file: file,
            fileName: fileName,
            isImage: isImage,
          );
      await ref.read(chatServiceProvider).sendAttachmentMessage(
            conversationId: widget.args.conversationId,
            type: isImage ? MessageType.image : MessageType.file,
            fileUrl: uploaded['url'] as String,
            fileName: fileName,
            fileSizeBytes: uploaded['size'] as int?,
          );
    } catch (e) {
      _showError(e);
    }
  }

  void _showError(Object e) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(e is AppException ? e.message : 'Something went wrong.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final messagesState = ref.watch(conversationMessagesProvider(widget.args.conversationId));
    final typingUsers = ref.watch(typingProvider(widget.args.conversationId));
    final myId = ref.watch(supabaseClientProvider).auth.currentUser?.id;

    return Scaffold(
      appBar: ChatHeader(
        title: widget.args.title,
        photoUrl: widget.args.photoUrl,
        subtitle: widget.args.isGroup ? 'Group' : '',
        onTitleTap: () {
          if (widget.args.isGroup) {
            Navigator.pushNamed(context, AppRoutes.groupInfo, arguments: widget.args.conversationId);
          }
        },
      ),
      body: Column(
        children: [
          Expanded(
            child: messagesState.when(
              loading: () => const LoadingView(),
              error: (e, _) => ErrorView(
                message: e is AppException ? e.message : 'Could not load messages.',
                onRetry: () => ref.invalidate(conversationMessagesProvider(widget.args.conversationId)),
              ),
              data: (messages) {
                if (messages.isEmpty) {
                  return const EmptyView(icon: Icons.chat_bubble_outline, title: 'Say hello 👋');
                }
                return ListView.builder(
                  controller: _scrollController,
                  reverse: true,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: messages.length,
                  itemBuilder: (context, i) {
                    final m = messages[i];
                    Message? replyPreview;
                    if (m.replyToMessageId != null) {
                      final match = messages.where((x) => x.id == m.replyToMessageId);
                      if (match.isNotEmpty) replyPreview = match.first;
                    }
                    return GestureDetector(
                      onDoubleTap: () => setState(() => _replyingTo = m),
                      child: ChatBubble(
                        message: m,
                        isMine: m.senderId == myId,
                        senderName: widget.args.isGroup && m.senderId != myId ? null : null,
                        replyPreview: replyPreview,
                        onDelete: m.senderId == myId
                            ? () => ref.read(chatServiceProvider).deleteMessage(m.id)
                            : null,
                      ),
                    );
                  },
                );
              },
            ),
          ),
          TypingIndicator(visible: typingUsers.isNotEmpty),
          MessageInput(
            replyingTo: _replyingTo,
            onCancelReply: () => setState(() => _replyingTo = null),
            onSend: _send,
            onPickImage: _pickImage,
            onPickFile: _pickFile,
            onTypingChanged: (isTyping) => ref
                .read(realtimeServiceProvider)
                .sendTyping(conversationId: widget.args.conversationId, isTyping: isTyping),
          ),
        ],
      ),
    );
  }
}
