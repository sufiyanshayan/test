import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/errors.dart';
import '../models/models.dart';
import '../routing/app_router.dart';
import '../screens/chat_screen.dart';
import '../state/providers.dart';
import '../widgets/common_widgets.dart';

class CreateGroupScreen extends ConsumerStatefulWidget {
  const CreateGroupScreen({super.key});
  @override
  ConsumerState<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends ConsumerState<CreateGroupScreen> {
  final _name = TextEditingController();
  final _query = TextEditingController();
  List<Profile> _searchResults = [];
  final Map<String, Profile> _selected = {};
  bool _creating = false;

  Future<void> _search(String text) async {
    final results = await ref.read(authServiceProvider).searchProfiles(text);
    if (mounted) setState(() => _searchResults = results);
  }

  Future<void> _create() async {
    if (_name.text.trim().isEmpty || _selected.isEmpty) return;
    setState(() => _creating = true);
    try {
      final conversationId = await ref.read(chatServiceProvider).createGroup(
            name: _name.text.trim(),
            memberIds: _selected.keys.toList(),
          );
      if (!mounted) return;
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.chat,
        arguments: ChatScreenArgs(
          conversationId: conversationId,
          title: _name.text.trim(),
          isGroup: true,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e is AppException ? e.message : 'Could not create group.')),
      );
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New group'),
        actions: [
          TextButton(
            onPressed: _creating ? null : _create,
            child: Text('Create', style: TextStyle(color: Theme.of(context).colorScheme.primary)),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Group name'),
            ),
          ),
          if (_selected.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 6,
                children: _selected.values
                    .map((p) => Chip(
                          label: Text(p.displayName),
                          onDeleted: () => setState(() => _selected.remove(p.id)),
                        ))
                    .toList(),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _query,
              decoration: const InputDecoration(labelText: 'Add members (search username)'),
              onChanged: _search,
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _searchResults.length,
              itemBuilder: (context, i) {
                final p = _searchResults[i];
                final isSelected = _selected.containsKey(p.id);
                return ListTile(
                  leading: AppAvatar(url: p.avatarUrl, fallbackText: p.displayName),
                  title: Text(p.displayName),
                  subtitle: Text('@${p.username}'),
                  trailing: Icon(isSelected ? Icons.check_circle : Icons.circle_outlined),
                  onTap: () => setState(() {
                    if (isSelected) {
                      _selected.remove(p.id);
                    } else {
                      _selected[p.id] = p;
                    }
                  }),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class GroupInfoScreen extends ConsumerStatefulWidget {
  final String conversationId;
  const GroupInfoScreen({super.key, required this.conversationId});
  @override
  ConsumerState<GroupInfoScreen> createState() => _GroupInfoScreenState();
}

class _GroupInfoScreenState extends ConsumerState<GroupInfoScreen> {
  GroupInfo? _info;
  List<GroupMemberInfo> _members = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final service = ref.read(chatServiceProvider);
    final info = await service.fetchGroupInfo(widget.conversationId);
    final members = await service.fetchGroupMembers(widget.conversationId);
    if (mounted) setState(() {
      _info = info;
      _members = members;
      _loading = false;
    });
  }

  GroupRole? get _myRole {
    final myId = ref.read(supabaseClientProvider).auth.currentUser?.id;
    final me = _members.where((m) => m.userId == myId);
    return me.isEmpty ? null : me.first.role;
  }

  bool get _iAmAdmin => _myRole == GroupRole.admin || _myRole == GroupRole.owner;

  Future<void> _promote(GroupMemberInfo m) async {
    await ref.read(chatServiceProvider).setMemberRole(widget.conversationId, m.userId, GroupRole.admin);
    _load();
  }

  Future<void> _demote(GroupMemberInfo m) async {
    await ref.read(chatServiceProvider).setMemberRole(widget.conversationId, m.userId, GroupRole.member);
    _load();
  }

  Future<void> _remove(GroupMemberInfo m) async {
    await ref.read(chatServiceProvider).removeGroupMember(widget.conversationId, m.userId);
    _load();
  }

  Future<void> _leave() async {
    await ref.read(chatServiceProvider).leaveGroup(widget.conversationId);
    if (mounted) {
      Navigator.popUntil(context, ModalRoute.withName(AppRoutes.home));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _info == null) {
      return const Scaffold(body: LoadingView());
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Group info')),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                AppAvatar(url: _info!.photoUrl, fallbackText: _info!.name, radius: 40),
                const SizedBox(height: 12),
                Text(_info!.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                if (_info!.description.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(_info!.description, textAlign: TextAlign.center),
                ],
              ],
            ),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text('${_members.length} members', style: TextStyle(color: Theme.of(context).hintColor)),
          ),
          ..._members.map((m) => ListTile(
                leading: AppAvatar(
                    url: m.profile?.avatarUrl, fallbackText: m.profile?.displayName ?? '?'),
                title: Text(m.profile?.displayName ?? 'Unknown'),
                subtitle: Text(m.role.name),
                trailing: _iAmAdmin && m.role != GroupRole.owner
                    ? PopupMenuButton<String>(
                        onSelected: (v) {
                          if (v == 'promote') _promote(m);
                          if (v == 'demote') _demote(m);
                          if (v == 'remove') _remove(m);
                        },
                        itemBuilder: (_) => [
                          if (m.role == GroupRole.member)
                            const PopupMenuItem(value: 'promote', child: Text('Make admin')),
                          if (m.role == GroupRole.admin)
                            const PopupMenuItem(value: 'demote', child: Text('Remove admin')),
                          const PopupMenuItem(value: 'remove', child: Text('Remove from group')),
                        ],
                      )
                    : null,
              )),
          const Divider(),
          ListTile(
            leading: Icon(Icons.exit_to_app, color: Theme.of(context).colorScheme.error),
            title: Text('Leave group', style: TextStyle(color: Theme.of(context).colorScheme.error)),
            onTap: _leave,
          ),
        ],
      ),
    );
  }
}
