# Threadline — Version 1

A private, WhatsApp-style messenger built with **Flutter + Supabase**. One-to-one chat, group chat, media sharing, typing/read receipts, and an original visual identity. Calling exists in the UI but is disabled — see `lib/core/config.dart`.

## ⚠️ About this codebase

This was generated in a sandboxed environment with **no network access and no Flutter SDK/emulator**, so it has not been run, compiled, or tested here — I could not run `flutter pub get`, `flutter analyze`, or launch a device. Treat this as a strong, architecturally-complete starting point, not a verified build. Run it locally, fix anything `flutter analyze` flags, and test each screen against your real Supabase project before relying on it.

## 1. Set up Supabase

1. Create a project at [supabase.com](https://supabase.com).
2. In the SQL Editor, run `supabase/migrations/0001_init.sql` — it creates every table, RLS policy, and the two storage buckets (`avatars`, `chat-media`).
3. In **Authentication → Providers**, make sure Email is enabled. For a small private user base, you can turn off "Confirm email" under **Authentication → Settings** to make onboarding faster.
4. Copy your **Project URL** and **anon public key** from **Settings → API**. Never use the `service_role` key in the app.

## 2. Run the Flutter app

```bash
flutter pub get

flutter run \
  --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR-ANON-KEY
```

For a release build, pass the same `--dart-define` flags to `flutter build apk`.

## 3. What's implemented (V1)

- Email/password auth, session persistence, logout
- Profile: avatar, display name, username, about, online/last-seen
- 1:1 chat: realtime messages, sent/delivered/read ticks, typing indicator, reply, delete, search
- Group chat: create, add/remove members, admin/owner roles, promote/demote, leave, group info screen
- Image + file sharing via Supabase Storage, with client-side compression and size/type limits
- Chat header shows Voice/Video call buttons that are visibly disabled and show "Calling is currently unavailable." — flip `FeatureFlags.callingEnabled` in `lib/core/config.dart` once WebRTC is wired up in V3
- Light/dark theme, loading/empty/error states, pull-to-refresh, keyset-paginated message history

## 4. Known gaps to close before shipping

- **Push notifications**: `notifications` table and `device_tokens` table exist, but the Edge Function that sends FCM pushes on new messages is not included — you'll need to add Firebase to the Android project (`google-services.json`) and write a `pg_net`/webhook-triggered Edge Function. This needs real device testing, which wasn't possible here.
- **Delivered vs. read distinction**: the client currently marks both `delivered` and `read` on receipt for simplicity; split these if you want a true "seen while app in background" state.
- **Offline queueing**: messages sent while offline currently just fail with a snackbar; add a local outbox if you want offline-first sending.
- **App icons / splash assets**: not generated — add your own via `flutter_launcher_icons` or manually.
- Run `flutter analyze` and `flutter test` locally — no linting or testing was performed in this environment.

## 5. Project structure

```
lib/
├── core/        # config, theme, error mapping, validators
├── models/       # data classes mirroring the Postgres schema
├── services/      # AuthService, ChatService, StorageService, RealtimeService
├── state/          # Riverpod providers
├── screens/         # one file/screen (or small group) per app screen
├── widgets/          # chat bubble, header, input, common states
└── routing/           # named route table
supabase/
└── migrations/0001_init.sql   # schema + RLS + storage policies
```

## 6. Upgrade path (already accounted for in the schema)

- **V2** (voice messages, forwarding, pinning): `message_type` already supports `voice`; add `forwarded_from_message_id` and a `pinned_messages` table when ready.
- **V3/V4** (calling): `call_sessions` table exists and is unused. Flip `FeatureFlags.callingEnabled`, add a signaling Edge Function + STUN/TURN, and build the call screens — no migration needed.
- **V5** (encryption, disappearing messages): add `expires_at` to `messages` and a cleanup job; E2EE would require client-side key management, which is a larger design step on its own.
