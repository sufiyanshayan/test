-- ============================================================
-- Threadline — Version 1 schema, RLS, and storage policies
-- Run this once against a fresh Supabase project (SQL editor
-- or `supabase db push`).
-- ============================================================

create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

-- ============ PROFILES ============
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null,
  avatar_url text,
  about text default '',
  status text not null default 'offline' check (status in ('online','offline')),
  last_seen timestamptz default now(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_profiles_username on profiles(username);

-- ============ CONVERSATIONS ============
create table conversations (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('direct','group')),
  created_by uuid references profiles(id),
  last_message_id uuid,
  last_message_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_conversations_last_message_at on conversations(last_message_at desc);

-- ============ CONVERSATION MEMBERS ============
create table conversation_members (
  conversation_id uuid references conversations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  joined_at timestamptz default now(),
  last_read_message_id uuid,
  is_muted boolean default false,
  primary key (conversation_id, user_id)
);
create index idx_conv_members_user on conversation_members(user_id);

-- ============ GROUPS ============
create table groups (
  conversation_id uuid primary key references conversations(id) on delete cascade,
  name text not null,
  description text default '',
  photo_url text,
  created_by uuid references profiles(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ============ GROUP MEMBERS ============
create table group_members (
  conversation_id uuid references conversations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin','owner')),
  added_at timestamptz default now(),
  primary key (conversation_id, user_id)
);

-- ============ MESSAGES ============
create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id uuid references profiles(id) on delete set null,
  message_type text not null default 'text'
    check (message_type in ('text','image','file','system','voice','location')),
  content text,
  reply_to_message_id uuid references messages(id) on delete set null,
  is_deleted boolean default false,
  deleted_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_messages_conversation_created on messages(conversation_id, created_at desc);
create index idx_messages_sender on messages(sender_id);

alter table conversations
  add constraint fk_last_message foreign key (last_message_id) references messages(id) on delete set null;

-- ============ MESSAGE ATTACHMENTS ============
create table message_attachments (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references messages(id) on delete cascade,
  file_url text not null,
  file_name text,
  file_type text,
  file_size_bytes bigint,
  width int,
  height int,
  created_at timestamptz default now()
);
create index idx_attachments_message on message_attachments(message_id);

-- ============ MESSAGE READS ============
create table message_reads (
  message_id uuid references messages(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  status text not null check (status in ('sent','delivered','read')),
  status_at timestamptz default now(),
  primary key (message_id, user_id)
);
create index idx_reads_user on message_reads(user_id);

-- ============ NOTIFICATIONS ============
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  type text not null check (type in ('message','mention','group_add','group_remove')),
  conversation_id uuid references conversations(id) on delete cascade,
  message_id uuid references messages(id) on delete cascade,
  is_read boolean default false,
  created_at timestamptz default now()
);
create index idx_notifications_user_unread on notifications(user_id, is_read);

-- ============ FUTURE: CALL SESSIONS (schema-ready, unused in V1) ============
create table call_sessions (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade,
  call_type text check (call_type in ('voice','video')),
  started_by uuid references profiles(id),
  status text check (status in ('ringing','active','ended','missed')),
  started_at timestamptz,
  ended_at timestamptz
);

-- ============ device tokens (for push notifications) ============
create table device_tokens (
  user_id uuid references profiles(id) on delete cascade,
  fcm_token text not null,
  platform text default 'android',
  created_at timestamptz default now(),
  primary key (user_id, fcm_token)
);

-- ============ updated_at trigger helper ============
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_profiles_updated before update on profiles
  for each row execute function set_updated_at();
create trigger trg_conversations_updated before update on conversations
  for each row execute function set_updated_at();
create trigger trg_messages_updated before update on messages
  for each row execute function set_updated_at();
create trigger trg_groups_updated before update on groups
  for each row execute function set_updated_at();

-- ============ auto-create profile row on signup ============
create or replace function handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, username, display_name)
  values (new.id, new.email, split_part(new.email, '@', 1));
  return new;
end;
$$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

alter table profiles enable row level security;
alter table conversations enable row level security;
alter table conversation_members enable row level security;
alter table groups enable row level security;
alter table group_members enable row level security;
alter table messages enable row level security;
alter table message_attachments enable row level security;
alter table message_reads enable row level security;
alter table notifications enable row level security;
alter table device_tokens enable row level security;

-- PROFILES
create policy "read any profile" on profiles for select using (true);
create policy "update own profile" on profiles for update using (auth.uid() = id);

-- CONVERSATIONS
create policy "select own conversations" on conversations for select
  using (exists (select 1 from conversation_members cm
                 where cm.conversation_id = id and cm.user_id = auth.uid()));

create policy "insert conversation if creator" on conversations for insert
  with check (created_by = auth.uid());

create policy "update conversation if member" on conversations for update
  using (exists (select 1 from conversation_members cm
                 where cm.conversation_id = id and cm.user_id = auth.uid()));

-- CONVERSATION_MEMBERS
create policy "select membership of own conversations" on conversation_members for select
  using (exists (select 1 from conversation_members cm
                 where cm.conversation_id = conversation_members.conversation_id
                 and cm.user_id = auth.uid()));

create policy "insert self or admin adds member" on conversation_members for insert
  with check (user_id = auth.uid()
    or exists (select 1 from group_members gm
               where gm.conversation_id = conversation_members.conversation_id
               and gm.user_id = auth.uid() and gm.role in ('admin','owner')));

create policy "delete own membership or admin removes" on conversation_members for delete
  using (user_id = auth.uid()
    or exists (select 1 from group_members gm
               where gm.conversation_id = conversation_members.conversation_id
               and gm.user_id = auth.uid() and gm.role in ('admin','owner')));

-- GROUPS
create policy "select group if member" on groups for select
  using (exists (select 1 from group_members gm
                 where gm.conversation_id = groups.conversation_id and gm.user_id = auth.uid()));

create policy "insert group if creator" on groups for insert
  with check (created_by = auth.uid());

create policy "update group if admin" on groups for update
  using (exists (select 1 from group_members gm
                 where gm.conversation_id = groups.conversation_id
                 and gm.user_id = auth.uid() and gm.role in ('admin','owner')));

-- GROUP_MEMBERS
create policy "select members if member" on group_members for select
  using (exists (select 1 from group_members gm
                 where gm.conversation_id = group_members.conversation_id and gm.user_id = auth.uid()));

create policy "insert member if self or admin" on group_members for insert
  with check (user_id = auth.uid()
    or exists (select 1 from group_members gm
               where gm.conversation_id = group_members.conversation_id
               and gm.user_id = auth.uid() and gm.role in ('admin','owner')));

create policy "update role if admin" on group_members for update
  using (exists (select 1 from group_members gm
                 where gm.conversation_id = group_members.conversation_id
                 and gm.user_id = auth.uid() and gm.role in ('admin','owner')));

create policy "delete member if self or admin" on group_members for delete
  using (user_id = auth.uid()
    or exists (select 1 from group_members gm
               where gm.conversation_id = group_members.conversation_id
               and gm.user_id = auth.uid() and gm.role in ('admin','owner')));

-- MESSAGES
create policy "select messages of own conversations" on messages for select
  using (exists (select 1 from conversation_members cm
                 where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));

create policy "insert own messages" on messages for insert
  with check (sender_id = auth.uid()
    and exists (select 1 from conversation_members cm
                where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));

create policy "update own messages" on messages for update
  using (sender_id = auth.uid());

-- MESSAGE_ATTACHMENTS
create policy "select attachments of visible messages" on message_attachments for select
  using (exists (select 1 from messages m
                 join conversation_members cm on cm.conversation_id = m.conversation_id
                 where m.id = message_attachments.message_id and cm.user_id = auth.uid()));

create policy "insert attachment for own message" on message_attachments for insert
  with check (exists (select 1 from messages m
                       where m.id = message_id and m.sender_id = auth.uid()));

-- MESSAGE_READS
create policy "select reads of own conversations" on message_reads for select
  using (exists (select 1 from messages m
                 join conversation_members cm on cm.conversation_id = m.conversation_id
                 where m.id = message_reads.message_id and cm.user_id = auth.uid()));

create policy "insert own read status" on message_reads for insert
  with check (user_id = auth.uid());
create policy "update own read status" on message_reads for update
  using (user_id = auth.uid());

-- NOTIFICATIONS
create policy "select own notifications" on notifications for select
  using (user_id = auth.uid());
create policy "update own notifications" on notifications for update
  using (user_id = auth.uid());

-- DEVICE TOKENS
create policy "manage own device tokens" on device_tokens for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ============================================================
-- STORAGE BUCKETS + POLICIES
-- ============================================================

insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('chat-media', 'chat-media', false)
on conflict (id) do nothing;

-- avatars: public read, owner-only write. Path convention: {user_id}/{file}
create policy "avatar public read" on storage.objects for select
  using (bucket_id = 'avatars');
create policy "avatar owner write" on storage.objects for insert
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatar owner update" on storage.objects for update
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- chat-media: private, members-only. Path convention: {conversation_id}/{file}
create policy "chat media read if member" on storage.objects for select
  using (
    bucket_id = 'chat-media'
    and exists (
      select 1 from conversation_members cm
      where cm.conversation_id = ((storage.foldername(name))[1])::uuid
      and cm.user_id = auth.uid()
    )
  );
create policy "chat media write if member" on storage.objects for insert
  with check (
    bucket_id = 'chat-media'
    and exists (
      select 1 from conversation_members cm
      where cm.conversation_id = ((storage.foldername(name))[1])::uuid
      and cm.user_id = auth.uid()
    )
  );
